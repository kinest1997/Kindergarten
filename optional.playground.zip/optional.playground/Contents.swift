import UIKit
//
//var carName: String?
//carName = nil
//carName = "Tank"
//
//// 아주 간단한 과제
////여러분이 최애 하는 영화배우의 이름을 담는 변수를 작성해주세요
//
//var myFavorite : String? = nil
////Int optional
//let num =  Int("10")
//
//
//myFavorite = "강동원"

//고급 기능 4가지

// Forced unwrapping
//Optional binding (if let)
//Optional binding (guard)
//nil coalescing



// Forced unwrapping   =   억지로 박스를 까보기
//Optional binding (if let)   =  부드럽게 박스를 까보자 1
//Optional binding (guard)    =    부드럽게 박스를 까보자 2
//nil coalescing    =   박스를 까봤더니, 값이 없으면 디폴트값을 줘보자
//carName = nil
//print(carName!)
//
//if let unwrappedCarName = carName {
//    print(unwrappedCarName)
//}else{
//    print("Car name 없다")
//}
//
//
//func printParsedInt (from: String) {
//    if let parsedInt = Int(from) {
//        print(parsedInt)
//    }
//    //Cyclomatic Complexity : 복잡성
//       else {
//        print("Int 로 컨버팅 안된다고")
//    }
//
//
//printParsedInt(from: "ㄴㅇㄹ")





func printParsedInt(from : String) {
    guard let parsedInt = Int(from) else{
        print("Int로 컨버팅 안된다고")
        return
    }
    print(parsedInt)
}
var carName = "테슬라"
let myCarName : String = carName ?? "모델 S"


    //도전과제
/* 1. 최애 음식 이름을 담는 변수를 작성 (string?)
 2.옵셔널 바인딩을 이용해서 값을 확인해보기
 3.닉네임을 받아서 출력하는 함수 만들기, 조건 입력 파라미터는 스트링
 */
let favoriteFood : String? = "양고기"


if let foodName = favoriteFood{
    print(foodName)
} else
{print("좋어허눈 음식 없ㅇ므")
}

func printNickName(name : String?) {
    guard let nickName = name else{
        print("닉네임 만들어보자")
        return
    }
    
    print(nickName)
}
printNickName(name: nil)
