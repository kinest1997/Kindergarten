import UIKit


func fullName(first : String, last : String){
    print("\(first)\(last)")
}


func fullName2( _ first : String, _ last : String){
    print("\(first)\(last)")
}

fullName(first: "강", last: "희성" )
fullName2("강", "희성")

func fullname3(first : String ,last : String) -> String {
    return "\(first)\(last)"
}
let printo = fullname3(first: "강", last: "휫송3")

for i in 1...9{
    for j  in 1...9{
        print("\(i)*\(j) = \(i * j)"  )
    }
}


func printTotalPrice(Price : Int, count : Int) {
    print("Total Price = \(Price*count)")
}

//in out parameter
var value = 3
func incrementAndPrint(_ value : inout Int) {
    value+=1
    print(value)
}

incrementAndPrint(&value)


func evenCheck(number : Int)-> Bool {
    var check : Bool
    if number % 2 == 0 {
        check = true
    }else {
        check = false
    }
    return Bool(check)
}

let love = evenCheck(number: 90)
print("\(love)")


func multi(x : Int, y : Int){
    print(x, y)
    print("\(x*y)")
}
multi(x: 98, y: 2)
