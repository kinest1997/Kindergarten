import UIKit

var str = "Hello, playground"

let value = arc4random_uniform(100)
print("-->\(value)")

// 한줄의 주석은 이렇게 남긴다

/*
 여러줄의 주석은
 이렇게 남긴다
 */

// --Tuple--

let coordinate = (4,6)

let x = coordinate.0
let y = coordinate.1

let coordinatesnamed = (x: 2, y: 3)

let x2 = coordinatesnamed.x
let y2 = coordinatesnamed.y


let (x3,y3) = coordinatesnamed

x3
y3

//--Boolean--

let yes = true
let no = false

let isFourGreaterThanFive = 4 > 5

if isFourGreaterThanFive {
    print("---참")
}
    else {
        print("---거짓")
    }

//if 조건 ....{
//    //조건이 참인 경우에 수행하는 코드를 적는다
//
//}else{
//    //그렇지 않은 경우에는 코드는 여기에
//
//}




let a = 5
let b = 10

if a > b {
    print("a 가 크다")
}else{print("b 가 크다")}


let name1 = "Jin"
let name2 = "Jason"
let isTwoNameSame = name1 == name2
if isTwoNameSame {
    print("이름이 같다")
}else{
    print("이름이 다르다")
}


let isMale = true
let jasonAndMale = isJason && isMale
let isJason = name2 == "Jason"
let jasonOrMale = isJason || isMale


let greetingMessage : String = isJason ? "hello Jason" : "Hello Somebody"


if isJason || isMale || jasonOrMale || jasonAndMale == true{
    print("맞습니다")
} else {print("틀립니다")}

print("Msg : \(greetingMessage)" )

func hello(){
var hours = 50
let payPerHour = 10000
var salary = 0

if hours > 40 {
    let extraHours = hours - 40
    salary += extraHours * payPerHour * 2
    hours -= extraHours

}
salary += hours * payPerHour

}

hello()



for j in 1...9{
    for i in 1...9{
        print("구구단 : \(i) * \(j) = \(i * j)")
    }
}
