import UIKit

var evennumbers : [Int] = [2,4,6,8]

evennumbers.append(10)
evennumbers += [12,14,16]
evennumbers.append(contentsOf: [18,20])


//let isEmpty = evennumbers.isEmpty

evennumbers.count

 

let firstitem = evennumbers.first

if let firstElement = evennumbers.first {
    print("first item is \(firstElement)")
}

evennumbers.max()
evennumbers.min()

evennumbers[6]


let firstThree = evennumbers[0...7]
evennumbers

evennumbers.contains(3)
evennumbers.contains(5)

evennumbers.insert(1, at: 1)

//evennumbers.removeAll()
// 위와 아래에 있는것은 같은것이다
//evennumbers = []

evennumbers[1] = -2
evennumbers

evennumbers[0...2] = [12,13,14]
evennumbers
evennumbers.swapAt(4, 7)



for num in evennumbers {
    print(num)
}

for(index,num) in evennumbers.enumerated() {
    print("idx : \(index), value : \(num)")
}

//배열에 영향은 주지않고 출력값만 정해진 갯수만큼 빼서 보여준다
evennumbers.dropFirst(3)

let firstThreeRemoved = evennumbers.dropFirst(3)

let lastRemoved = evennumbers.dropLast()

let FirstThree = evennumbers.prefix(3)

let lastThree = evennumbers.suffix(3)
