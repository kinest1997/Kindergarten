import UIKit

func printName() {
    print("My name is Heesung")
}
printName()

// param 1개
// 숫자를 받아서 10을 곱해서 출력한다

func printMultipleOfTen(value:Int) {
    print("\(value) * 10 = \(value * 10)")
}
printMultipleOfTen(value: 322)

// param 2개
// 물건 값과 갯수를 받아서 전체 금액을 출력하는 함수
func multiple( price : Int ,  count : Int ) {
    print("Total Price : \(count * price)")
}

//multiple(count: 22, price: 1000)
//
//


multiple(price : 1500, count : 20)

func multipleDefault( price : Int = 1500 ,  count : Int ) {
    print("Total Price : \(count * price)")
}
multipleDefault(price : 2222 , count: 5)


//function as a parameter

func add(_ a: Int, _ b: Int) -> Int {
    return a + b
}
func subtract (_ a:Int, _ b: Int ) -> Int {
    return a - b
}

var function = add
function(4,2)
function = subtract
function(4,2)

func printResult(_ function: (Int, Int)-> Int,_ a: Int, _ b:Int ){
    let result = function(a,b)
    print(result)
}

printResult(add,10,5)
printResult(subtract, 10, 5)


func nameMaker( _ first : String, _ last : String) {
    print("\(first)\(last)")
}

nameMaker("김","희성")


func nameMan(_ first : String,_ last : String) -> String {
    return "\(first)\(last)"
}
let mice = nameMan("kane", "harry")
mice



var carName : String?

let number = Int("10")



let alpha = 2
let alpha2 = 3
let isTwoName = alpha == alpha2



